# 🍽️ Savoria — Modern Restaurant & Dining Experience

**Good food. Beautiful moments.** ✨

Savoria is a responsive restaurant website concept showcasing a modern dining experience, featured dishes, interactive order selection, and a table reservation request form.

## 🌐 Project Name
**Savoria — Modern Restaurant & Dining Experience**

## 📝 GitHub Description
A modern, responsive restaurant website featuring a curated menu, add-to-order interactions, and a table reservation request form. Built with HTML, CSS, and JavaScript, with an elegant dining-inspired design.

## 🔗 Live Website
https://pixel-perfect-showcase-4470.lovable.app

## ✨ Features
- Responsive layout for desktop and mobile
- Restaurant story and featured dishes
- Add-to-order interaction with a running total
- Reservation form with name, email, guest count, date, time, and special requests
- Date picker prevents selecting a date before today
- Mobile navigation menu
- Elegant typography and restaurant imagery

## 🧭 User Workflow
1. Explore the restaurant homepage and story.
2. Browse the featured dishes.
3. Add dishes to the order panel and review the total.
4. Open the reservation section.
5. Enter contact details, guest count, date, time, and any special requests.
6. Submit the form to see the demo confirmation.

## 🛠️ Built With
- HTML
- CSS
- JavaScript
- Google Fonts
- Unsplash image URLs

## 🚀 Run Locally
1. Download or clone this repository.
2. Open `index.html` in a modern web browser.

No build tools are required for this static starter version.

## ⚠️ Important Note
This is a reconstructed starter source package, not a direct export of the private/original Lovable project. The live Lovable website and this package remain separate unless the original project is synced through Lovable's GitHub integration.

The reservation form currently displays a demo confirmation. It does **not** send reservations to a restaurant or backend.

## 🏷️ GitHub Topics
`restaurant-website` `restaurant-booking` `responsive-design` `frontend` `html` `css` `javascript` `lovable`

## 🌱 Future Improvements
- Connect reservations to a backend or webhook
- Add menu categories and more dishes
- Add order editing and quantity controls
- Add validation and confirmation emails
- Improve accessibility and test across browsers

## 📄 License
No license has been specified. Add a license file if you want to define how others may use, modify, or distribute this project.

---
**Made for memorable meals.** 🍽️
